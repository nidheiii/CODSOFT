package com.example.attendance;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AbsenteesActivity extends AppCompatActivity {

    private ListView absenteesListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_absentees);

        absenteesListView = findViewById(R.id.absentees_list_view);

        Intent intent = getIntent();
        ArrayList<String> absentees = intent.getStringArrayListExtra("absentees");

        if (absentees != null && !absentees.isEmpty()) {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, absentees);
            absenteesListView.setAdapter(adapter);
        } else {
            Toast.makeText(this, "No absentees found", Toast.LENGTH_SHORT).show();
        }
    }
}
