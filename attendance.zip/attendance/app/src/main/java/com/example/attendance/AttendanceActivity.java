package com.example.attendance;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class AttendanceActivity extends AppCompatActivity {

    private ListView studentListView;
    private Button submitButton;
    private StudentAdapter studentAdapter;
    private List<Student> students;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        studentListView = findViewById(R.id.student_list_view);
        submitButton = findViewById(R.id.submit_button);

        // Initialize the student list
        students = new ArrayList<>();
        students.add(new Student("AADHITYA E"));
        students.add(new Student("ABINAYA E"));
        students.add(new Student("AISHWARIYA LAKSHMI M"));
        students.add(new Student("AISHWARYA K"));
        students.add(new Student("ANANTH KRSHNAN A"));
        students.add(new Student("ASVANTH S"));
        students.add(new Student("BALAMOHANAN M"));
        students.add(new Student("BALASUNDAR B"));
        students.add(new Student("BHUVANESHWAR C"));
        students.add(new Student("CHANDRAMOULY V"));
        students.add(new Student("DEEPIKA V"));
        students.add(new Student("DEVISREE N"));
        students.add(new Student("DHARANIDHARAN P"));
        students.add(new Student("DHIVYA PRASATH J"));
        students.add(new Student("ELAKKIYAN S"));
        students.add(new Student("GNANESWARAN J S"));
        students.add(new Student("GOKUL L"));
        students.add(new Student("HAMSANA S"));
        students.add(new Student("HARIHARAN C"));
        students.add(new Student("HARIKARAN A"));
        students.add(new Student("HARITHIRA A"));
        students.add(new Student("HEMAPRABA K"));
        students.add(new Student("JAASEEM J"));
        students.add(new Student("JEEVASHRI S"));
        students.add(new Student("KANIMOZHI N"));
        students.add(new Student("KAVYA K"));
        students.add(new Student("KEERTHIGA M"));
        students.add(new Student("KERTHI M"));
        students.add(new Student("KIRUTHIKA R"));
        students.add(new Student("KISHKINDHAN R"));
        students.add(new Student("KUMARAGURU M"));
        students.add(new Student("LOKSHANA S"));
        students.add(new Student("MAGESH A"));
        students.add(new Student("MANIKANDAN K"));
        students.add(new Student("MOHAMMED NAASIF H N"));
        students.add(new Student("NARMADHA P"));
        students.add(new Student("NIDHISH KUMAR P"));
        students.add(new Student("NITHIN S"));
        students.add(new Student("NITHYAPRIYA S"));
        students.add(new Student("PRADEEPKUMAR A"));
        students.add(new Student("ROSHAN A"));
        students.add(new Student("ROSHINI NIVADA P"));
        students.add(new Student("SAMIKSHA P"));
        students.add(new Student("SAMYUKTHA A"));
        students.add(new Student("SANJAYKUMAR S"));
        students.add(new Student("SANJEEVI R"));
        students.add(new Student("SANTHANALAKSHME N S"));
        students.add(new Student("SHARATH R"));
        students.add(new Student("SHOWPARNICA D"));
        students.add(new Student("SILAMBARASAN B"));
        students.add(new Student("SOORIYA R"));
        students.add(new Student("SOUNDARYA P"));
        students.add(new Student("SUBASREE S"));
        students.add(new Student("SURENDAR B"));
        students.add(new Student("SURIYA S K"));
        students.add(new Student("THANUSHIKA K"));
        students.add(new Student("VARUN PRADEEP"));
        students.add(new Student("VERONICA A"));
        students.add(new Student("VINITHA R"));
        students.add(new Student("VISHVA G"));
        students.add(new Student("NITHYA SHASTHA R"));
        students.add(new Student("GUNANITHI S"));
        students.add(new Student("KISHORE R"));
        students.add(new Student("GEESALA RESHMA MOULIKA"));
        students.add(new Student("OLETI BABY"));
        students.add(new Student("MADHUBALAN"));

        studentAdapter = new StudentAdapter(this, students);
        studentListView.setAdapter(studentAdapter);

        submitButton.setOnClickListener(v -> {
            List<String> absentees = new ArrayList<>();
            for (Student student : students) {
                if ("Absent".equals(student.getAttendance())) {
                    absentees.add(student.getName());
                    Log.d("AttendanceActivity", "Added absentee: " + student.getName()); // Log for debugging
                }
            }

            Intent intent = new Intent(AttendanceActivity.this, AbsenteesActivity.class);
            intent.putStringArrayListExtra("absentees", new ArrayList<>(absentees));
            startActivity(intent);
        });
    }
}
