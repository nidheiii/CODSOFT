package com.example.attendance;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button advisorLoginButton;
    private Button staffLoginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        advisorLoginButton = findViewById(R.id.advisor_login_button);
        staffLoginButton = findViewById(R.id.staff_login_button);

        advisorLoginButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AdvisorLoginActivity.class);
            startActivity(intent);
        });

        staffLoginButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, StaffLoginActivity.class);
            startActivity(intent);
        });
    }
}
