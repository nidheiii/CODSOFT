package com.example.attendance;

public class Student {
    private String name;
    private String attendance;

    public Student(String name) {
        this.name = name;
        this.attendance = "Present"; // Default value
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }
}
